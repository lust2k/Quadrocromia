package dominioDoProblema;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Arrays;
import java.util.Collections;

import javax.swing.JButton;
import javax.swing.JOptionPane;

import dominioDoProblema.Jogador;
import interfaceGrafica.InterfaceJogador;

public class Tabuleiro implements ActionListener, MouseListener {
	
	protected boolean partidaEmAndamento;
	protected Posicao[][] matrizPosicao;
	public InterfaceJogador atorJogador;
	protected Jogador jogadorLocal;
	protected Jogador jogadorRemoto;
	protected Peca pecas[];
	protected JButton[][] botoesTabuleiro;
	protected JButton[] botoesInventario1;
	protected JButton[] botoesInventario2;
	public MouseEvent evento;
	
	
	
	public Tabuleiro(JButton[][] botoesTabuleiro, JButton[] botoesInventario1, JButton[] botoesInventario2) {
		super();
		matrizPosicao = new Posicao[6][6];
		pecas = new Peca[18];
		this.botoesTabuleiro = botoesTabuleiro;
		this.botoesInventario1 = botoesInventario1;
		this.botoesInventario2 = botoesInventario2;
		partidaEmAndamento = false;
		atorJogador = new InterfaceJogador();
		
	}
	
	public Tabuleiro() {}	
	
	public void colocarPeca(int linha, int coluna, int tamanho, String cor, boolean horizontal, MouseEvent e) {
		if (e.getSource() == botoesTabuleiro[linha][coluna]) {
			botoesTabuleiro[linha][coluna].setBackground(Color.red);
			Lance lance = new Lance(linha, coluna, 1, "vermelho", false);
			atorJogador.enviarJogada(lance);
			// verifica se partida acabou
		}		
	}
	
	/* public Posicao obterPosicao(int linha, int coluna, int tamanho, String cor) {
		
	} */
	
	public boolean informarTurno() {
		if (jogadorLocal.informarTurno()) return true;
		return false;
	}
	
	private void iniciar() {
		partidaEmAndamento = false;
	}

	public boolean encerrarPartida() {
		if (partidaEmAndamento) {
			esvaziarTabuleiro();
			jogadorLocal = new Jogador();
			jogadorRemoto = new Jogador();
			return true;
		}
		return false;
	}
	
	public void embaralhaPecas() {
		pecas[0] = new Peca("verde", 2);
		pecas[1] = new Peca("verde", 2);
		pecas[2] = new Peca("verde", 3);
		pecas[3] = new Peca("verde", 3);
		pecas[4] = new Peca("vermelho", 1);
		pecas[5] = new Peca("vermelho", 1);
		pecas[6] = new Peca("vermelho", 2);
		pecas[7] = new Peca("vermelho", 2);
		pecas[8] = new Peca("azul", 1);
		pecas[9] = new Peca("azul", 1);
		pecas[10] = new Peca("azul", 1);
		pecas[11] = new Peca("azul", 2);
		pecas[12] = new Peca("azul", 2);
		pecas[13] = new Peca("azul", 3);
		pecas[14] = new Peca("azul", 3);
		pecas[15] = new Peca("amarelo", 1);
		pecas[16] = new Peca("amarelo", 3);
		pecas[17] = new Peca("amarelo", 3);
		Collections.shuffle(Arrays.asList(pecas));
			
	}
	
	public void distribuirPecas() {
		embaralhaPecas();
		for (int i = 0; i < 9; i++) {
			jogadorLocal.inventario.arrayPecas[i] = pecas[i];
		}
		for (int i = 9; i < 18; i++) {
			jogadorRemoto.inventario.arrayPecas[i] = pecas[i-9];
		}
	}
		
	public void esvaziarTabuleiro() {
		for (int i = 0; i < 6; i++) {
			for (int j = 0; j < 6; j++) {
				matrizPosicao[i][j].defineCor("branco");
			}
		}
	}

	
	public void iniciarNovaPartida(int ordem, String adversario) {
		esvaziarTabuleiro();
		jogadorLocal = new Jogador();
		jogadorRemoto = new Jogador();
		jogadorRemoto.definirNome(adversario);
		if (ordem == 1) jogadorLocal.definirComoPrimeiro();
		else jogadorRemoto.definirComoPrimeiro();
		definirPartidaEmAndamento(true);
	}
	
	public void definirPartidaEmAndamento(boolean partidaEmAndamento) {
		this.partidaEmAndamento = partidaEmAndamento;
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		evento = e;
		if (e.getSource() == botoesInventario1[0]) {
			//checa a peca selecionada
		}
		
		for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 6; j++) {
            		colocarPeca(i,j, 1, "vermelho", false, evento);
            }
		}
			
		
	}
	
	public void registrarJogadorLocal(String jogador) {
		jogadorLocal = new Jogador();
		jogadorLocal.definirNome(jogador);
		jogadorLocal.iniciar();
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	
}
