package dominioDoProblema;

import javax.swing.ImageIcon;

public class Peca {
	
	protected boolean disponivel;
	protected String corPeca;
	protected int tamanho;
	protected boolean horizontal;
	protected ImageIcon icone;
	
	public Peca(String corPeca, int tamanho) {
		this.disponivel = true;
		this.corPeca = corPeca;
		this.tamanho = tamanho;
		this.horizontal = false;
		setIcon();
	}
	
	public String girarPeca() {
		if (disponivel) {
			horizontal = !horizontal;
			return(null);
		} else {
			return("A��o inv�lida");
		}
	}
	
    // imagens das pe�as
    ImageIcon branco = new ImageIcon(getClass().getResource("imagens/branco.png")); // n�mero de pe�as:
    ImageIcon verde2 = new ImageIcon(getClass().getResource("imagens/verde2.png")); // 2
    ImageIcon verde3 = new ImageIcon(getClass().getResource("imagens/verde3.png")); // 2
    ImageIcon vermelho1 = new ImageIcon(getClass().getResource("imagens/vermelho1.png")); // 2
    ImageIcon vermelho2 = new ImageIcon(getClass().getResource("imagens/vermelho2.png")); // 2
    ImageIcon amarelo1 = new ImageIcon(getClass().getResource("imagens/amarelo1.png")); // 1
    ImageIcon amarelo3 = new ImageIcon(getClass().getResource("imagens/amarelo3.png")); // 2
    ImageIcon azul1 = new ImageIcon(getClass().getResource("imagens/azul1.png")); // 3
    ImageIcon azul2 = new ImageIcon(getClass().getResource("imagens/azul2.png")); // 2
    ImageIcon azul3 = new ImageIcon(getClass().getResource("imagens/azul3.png")); // 2
	
	public void setIcon() {
		if (this.tamanho == 2 && this.corPeca == "verde") {
			this.icone = verde2;
		}
		if (this.tamanho == 3 && this.corPeca == "verde") {
			this.icone = verde3;
		}
		if (this.tamanho == 1 && this.corPeca == "vermelho") {
			this.icone = vermelho1;
		}
		if (this.tamanho == 2 && this.corPeca == "vermelho") {
			this.icone = vermelho2;
		}		
		if (this.tamanho == 1 && this.corPeca == "amarelo") {
			this.icone = vermelho1;
		}
		if (this.tamanho == 3 && this.corPeca == "amarelo") {
			this.icone = vermelho1;
		}
		if (this.tamanho == 1 && this.corPeca == "azul") {
			this.icone = azul1;
		}
		if (this.tamanho == 2 && this.corPeca == "azul") {
			this.icone = azul2;
		}
		if (this.tamanho == 3 && this.corPeca == "azul") {
			this.icone = azul3;
		}
		
	}
	
	public boolean informarDisponivel() {
		return disponivel;
	}
	
	public String informarCorPeca() {
		return corPeca;
	}
	
	public int informarTamanho() {
		return tamanho;
	}
	
	public boolean informarHorizontal() {
		return horizontal;
	}
}
