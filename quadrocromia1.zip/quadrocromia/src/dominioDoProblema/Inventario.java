package dominioDoProblema;

public class Inventario {
	
	protected Peca[] arrayPecas = new Peca[9];
	
	public void recebePeca(Peca peca, int posicao) {
		arrayPecas[posicao] = peca;
	}
	
	public Peca informaPeca(int posicao) {
		return arrayPecas[posicao];
	}
}
