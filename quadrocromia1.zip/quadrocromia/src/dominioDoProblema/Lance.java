package dominioDoProblema;

import br.ufsc.inf.leobr.cliente.Jogada;

public class Lance implements Jogada {
	
	private static final long serialVersionUID = -7925382400008937099L;
	protected int linha;
	protected int coluna;
	protected int tamanhoPeca;
	protected String corPeca;
	protected boolean horizontal;
	
	public Lance(int linha, int coluna, int tamanho, String cor, boolean horizontal) {
		this.linha = linha;
		this.coluna = coluna;
		this.tamanhoPeca = tamanho;
		this.corPeca = cor;
		this.horizontal = horizontal;
	}
	
	public int informarLinha() {
		return linha;
	}
	
	public int informarColuna() {
		return coluna;
	}

	public int informarTamanho() {
		return tamanhoPeca;
	}
	
	public String informarCor() {
		return corPeca;
	}

}
