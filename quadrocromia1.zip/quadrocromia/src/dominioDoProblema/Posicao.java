package dominioDoProblema;

public class Posicao {

	protected boolean ocupado;
	protected String cor;
	
	public Posicao(boolean ocupado, String cor) {
		this.ocupado = ocupado;
		this.cor = cor;
	}
	
	public String informaCor() {
		return cor;
	}
	
	public boolean informaOcupado() {
		return ocupado;
	}
	
	public void defineCor(String cor) {
		this.cor = cor;
	}
	
	public void defineOcupado(boolean ocupado) {
		this.ocupado = ocupado;
	}
	
	/* public avaliaExistenciaJogadaValida(boolean parameter) {
	
	} */
	
}
