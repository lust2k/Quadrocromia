package dominioDoProblema;

public class Jogador {

	protected String nome;
	protected boolean turnoAtivo;
	protected boolean vencedor;
	protected Inventario inventario;
	
	public Jogador() {
		turnoAtivo = false;
		vencedor = false;
	}
	
	public void definirNome(String jogador) {
		nome = jogador;
	}
	
	public void definirComoPrimeiro() {
		turnoAtivo = true;
	}
	
	public void definirVencedor(boolean valor) {
		vencedor = valor;
	}
	
	public String informarNome() {
		return nome;
	}
	
	public boolean informarTurno() {
		return turnoAtivo;
	}
	
	public boolean informarVencedor() {
		return vencedor;
	}
	
	public void inverterTurno() {
		turnoAtivo = !turnoAtivo;
	}
	
	public void iniciar() {
		turnoAtivo = false;
		vencedor = false;
	}
	
	public void recebePeca(String cor, int tamanho, int posicao) {
		Peca p = new Peca(cor, tamanho);
		inventario.recebePeca(p, posicao);
	}
	
	public boolean maoVazia() {
		for (int i = 0; i < 9; i++) {
			if (inventario.informaPeca(i).informarDisponivel() == true) return false;
		}
		return true;
	}
}
