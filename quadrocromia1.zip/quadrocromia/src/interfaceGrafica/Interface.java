package interfaceGrafica;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import dominioDoProblema.Lance;
import dominioDoProblema.Tabuleiro;
import java.awt.event.MouseListener;

public class Interface extends JFrame {
    private static final long serialVersionUID = 5959874721938974760L;
    protected InterfaceJogador interfaceJogador;
    protected boolean pecaSelecionada = false;
    protected boolean conectado = false;
    protected boolean jogadoresProntos = false;
    protected String nomeJogador;
    protected String enderecoServidor;
    protected JLabel mensagem;
    protected Tabuleiro tabuleiro_;
    public JButton[][] botoesTabuleiro;
    public JButton[] botoesInventario1;
    public JButton[] botoesInventario2;
    
    public Interface() {
    	super();
    	interfaceJogador = new InterfaceJogador(this);
        // frame
        Container contentPane = getContentPane();
        contentPane.setLayout(new BorderLayout());
        
        // panel com toolbar e inventario1 na regi�o norte do frame
        JPanel topo = new JPanel();
        topo.setLayout(new BoxLayout(topo, BoxLayout.PAGE_AXIS));
        contentPane.add(topo, BorderLayout.NORTH);
        
        // toolbar
        JToolBar toolbar = new JToolBar("Menu");
        toolbar.setFloatable(false);
        toolbar.setBackground(Color.WHITE);
        topo.add(toolbar);
        // bot�es da toolbar
        JButton conectar = new JButton("Conectar");
        conectar.setBackground(Color.WHITE);
        toolbar.add(conectar);
        JButton iniciarPartida = new JButton("Iniciar Partida");
        iniciarPartida.setBackground(Color.WHITE);
        toolbar.add(iniciarPartida);
        JButton desconectar = new JButton("Desconectar");
        desconectar.setBackground(Color.WHITE);
        toolbar.add(desconectar);
        
        toolbar.addSeparator(new Dimension(200, 0));
        mensagem = new JLabel("");
        toolbar.add(mensagem);
        
        // a��es dos bot�es da toolbar
        ActionListener eventosToolbar = new ActionListener() {
        	@Override
        	public void actionPerformed(ActionEvent e) {
        		if (e.getSource() == conectar) {
        			nomeJogador = JOptionPane.showInputDialog("Insira seu nome.");
        			enderecoServidor = JOptionPane.showInputDialog("Insira o endere�o do servidor.");
        			interfaceJogador.conectar();
        		} else if (e.getSource() == iniciarPartida) {
        			interfaceJogador.iniciarPartida();
        		} else if (e.getSource() == desconectar) {
        			interfaceJogador.desconectar();
        		}
        	}
        };
        
        conectar.addActionListener(eventosToolbar);
        iniciarPartida.addActionListener(eventosToolbar);
        desconectar.addActionListener(eventosToolbar);
        
        Insets buttonMargin = new Insets(1,1,1,1);
        
        // inventario1
        JPanel inventario1 = new JPanel();
        topo.add(inventario1, BorderLayout.NORTH);
        botoesInventario1 = new JButton[9];
        // inventario2
        JPanel inventario2 = new JPanel();
        contentPane.add(inventario2, BorderLayout.SOUTH);
        botoesInventario2 = new JButton[9];
        botoesTabuleiro = new JButton[6][6];
        tabuleiro_ = new Tabuleiro(botoesTabuleiro, botoesInventario1, botoesInventario2);

        
        ImageIcon branco = new ImageIcon(getClass().getResource("imagens/branco.png"));
        ImageIcon branco3 = new ImageIcon(getClass().getResource("imagens/branco3.png"));
        
        
        // cria pe�as e insere no inventario1 e no inventario2
        for (int i = 0; i < botoesInventario1.length; i++) {
        	botoesInventario1[i] = new JButton();
        	botoesInventario1[i].setMargin(buttonMargin);
        	botoesInventario1[i].setBackground(Color.WHITE);
        	botoesInventario1[i].addMouseListener(tabuleiro_);
        	botoesInventario1[i].setIcon(branco3);
        	inventario1.add(botoesInventario1[i]);

        }
        
        for (int i = 0; i < botoesInventario2.length; i++) {
        	botoesInventario2[i] = new JButton();
        	botoesInventario2[i].setMargin(buttonMargin);
        	botoesInventario2[i].setBackground(Color.WHITE);
        	botoesInventario2[i].addMouseListener(tabuleiro_);
        	botoesInventario2[i].setIcon(branco3);
        	inventario2.add(botoesInventario2[i]);
        }
        
        


        // a��es dos bot�es do tabuleiro
     
        
        
        // tabuleiro
        JPanel tabuleiroPanel = new JPanel();
        tabuleiroPanel.setLayout(new GridLayout(6, 6));
        for (int i = 0; i < 6; i++) {
        	for (int j = 0; j < 6; j++) {
        		botoesTabuleiro[i][j] = new JButton();
        		botoesTabuleiro[i][j].setPreferredSize(new Dimension(64, 64));
        		botoesTabuleiro[i][j].setMargin(buttonMargin);
        		botoesTabuleiro[i][j].setBackground(Color.WHITE);
        		botoesTabuleiro[i][j].addMouseListener(tabuleiro_);
            	tabuleiroPanel.add(botoesTabuleiro[i][j]);
        	}
        }
        
        
        contentPane.add(tabuleiroPanel, BorderLayout.CENTER);
                
        
    }
        
    public void exibirMensagem(String mensagem) {
    	this.mensagem = new JLabel(mensagem);
    }
        
    public String obterNomeJogador() {
    	return nomeJogador;
    }
    
    public String obterEnderecoServidor() {
    	return enderecoServidor;
    }
    
    public void atualizarTabuleiro(Lance lance) {
    	botoesTabuleiro[lance.informarLinha()][lance.informarColuna()].setBackground(Color.red);
    }
    
	public void receberJogada(Lance lance) {
		tabuleiro_.definirPartidaEmAndamento(true);
		atualizarTabuleiro(lance);
		
	}
    
    public void notificar(String notificacao) {
    	JOptionPane.showMessageDialog(null, notificacao);
    }
    
    public static void main(String[] args) {
        Interface frame = new Interface();
        frame.setTitle("Quadrocromia");
        frame.pack();
        frame.setMaximumSize(frame.getSize());
        frame.setVisible(true);
        frame.setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

}