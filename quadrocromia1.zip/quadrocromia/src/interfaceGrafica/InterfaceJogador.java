package interfaceGrafica;

import rede.InterfaceNetgamesServer;
import dominioDoProblema.Tabuleiro;
import dominioDoProblema.Lance;

public class InterfaceJogador {
	
	protected InterfaceNetgamesServer ngames;
	protected Interface gui;
	protected Tabuleiro tabuleiro;

	public InterfaceJogador() {
		ngames = new InterfaceNetgamesServer();
		tabuleiro = new Tabuleiro();
	}
	
	public InterfaceJogador(Interface interfaceQuadrocromia) {
		super();
		iniciar(interfaceQuadrocromia);
	}
	
	private void iniciar(Interface interfaceQuadrocromia) {
		gui = interfaceQuadrocromia;
		ngames = new InterfaceNetgamesServer();
		tabuleiro = new Tabuleiro();
		ngames.definirInterfaceJogador(this);
	}

	public void conectar() {
		boolean conectado = ngames.informarConectado();
		if(!conectado) {
			String jogador = gui.obterNomeJogador();
			String servidor = gui.obterEnderecoServidor();
			String notificacao = ngames.conectar(servidor, jogador);
			tabuleiro.registrarJogadorLocal(jogador);
			gui.notificar(notificacao);
		} else {
			gui.notificar("Voc� j� est� conectado.");
		}
	}
	
	 public void receberJogada(Lance lance) {
		gui.receberJogada(lance);
	}
	
	public boolean desconectar() {
		boolean conectado = ngames.informarConectado();
		boolean atualizarInterface = true;
		if(conectado) {
			//atualizarInterface = tabuleiro.encerrarPartida(); // encerra a partida via cliente
			if (atualizarInterface) ngames.encerrarPartida(); // encerra a partida via servidor
			ngames.desconectar();
			gui.notificar("Desconectado com sucesso.");
		} else {
			gui.notificar("Voc� n�o est� conectado.");
		}
		return atualizarInterface;
	}
	
	public boolean iniciarPartida() {
		boolean conectado = ngames.informarConectado();
		boolean atualizarInterface = false;
		if(conectado) {
			atualizarInterface = tabuleiro.encerrarPartida(); // encerra a partida via cliente
			if (atualizarInterface) ngames.encerrarPartida(); // encerra a partida via servidor
			ngames.iniciarPartida();
		} else {
			gui.notificar("Voc� n�o est� conectado.");
		}
		return atualizarInterface;
	}
	
	public void iniciarNovaPartida(Integer ordem, String adversario) {
		tabuleiro.iniciarNovaPartida(ordem, adversario);
	}
	
	public void encerrarPartida() {
		boolean atualizar = tabuleiro.encerrarPartida();
		gui.notificar("Partida finalizada");
	}
	
	public void enviarJogada(Lance lance) {
		ngames.enviarJogada(lance);
	}
}
