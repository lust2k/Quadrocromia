module quadrocromia {
	requires ngnrtFramework;
	requires java.desktop;
}